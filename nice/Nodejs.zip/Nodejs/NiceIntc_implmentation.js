const express = require("express");
const app = express();
const axios = require("axios");
const session = require('express-session');
const crypto = require('crypto');

// NICE평가정보로 부터 전달 받은 clientId, clientSecret 
var CLIENT_ID = "";                                     
var CLIENT_SECRET = ""; 

app.get("/intcMain", async (req, res) => {
    try {
        let accessToken, iterators, ticket;
        // 세션에 토큰 있으면 그대로 사용 
        if (
            req.session.accessToken && 
            req.session.iterators &&
            req.session.ticket
        ) {
            accessToken = req.session.access_token;
            iterators = req.session.iterators;
            ticket = req.session.ticket;
            console.log('세션 토큰 재사용');
        } 
        //세션에 토큰이 없으면 24시간 유효한 접근 토큰 발급 진행
        else {
            // 요청 고유 번호 생성 - 최소 20byte ~ 최대 50byte 내
            const requestNo = 'REQ' +new Date().toISOString().replace(/[-T:.Z]/g, '').slice(0, 14) +'/' +crypto.randomBytes(14).toString('hex').slice(0, 27);
            // 접근 토큰 요청 API 호출 URI - https://auth.niceid.co.kr/ido/intc/v1.0/auth/token
            const tokenurl = 'https://auth.niceid.co.kr/ido/intc/v1.0/auth/token'
            const Auth = CLIENT_ID + ':' + CLIENT_SECRET;
            const base64Auth = Buffer.from(Auth).toString('base64').replace(/=+$/, '');

            // 접근 토큰 API 요청
            const tokenResponse = await axios.post( tokenurl,
                { 
                    grant_type: 'client_credentials',
                    request_no: requestNo
                },{ 
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Basic ' + base64Auth,
                        'X-Intc-DevLang': 'DI/NODEJS'
                    }
                });
            console.log('토큰 신규 발급', tokenResponse.data);
            accessToken = tokenResponse.data.access_token;
            iterators = tokenResponse.data.iterators;
            ticket = tokenResponse.data.ticket;

            // 예시에서는 세션에 저장하여 확인
            req.session.accessToken = accessToken;
            req.session.iterators = iterators;
            req.session.ticket = ticket;
        }
        
        // 인증 URL 요청 API 호출 URI - https://auth.niceid.co.kr/ido/intc/v1.0/auth/url
        const urlAuth = 'https://auth.niceid.co.kr/ido/intc/v1.0/auth/url'

        //// 요청 고유 번호 생성 - 20~50byte 사용 가능하며, 비지니스 로직에 따라 수정 가능한 매서드
        const requestNo = 'REQ' +new Date().toISOString().replace(/[-T:.Z]/g, '').slice(0, 14) +'/' +crypto.randomBytes(14).toString('hex').slice(0, 27);
        const urlResponse = await axios.post( urlAuth,
                // 인증 URL 요청 데이터 
                { 
                    'return_url' : '',         // 인증 URL에서 사용자가 본인확인이 완료되면 이동하는 페이지
                    'close_url' : '',          // 본인확인 진행 시 팝업창 내 close 버튼(X) 클릭 시 이동하는 페이지
                    'svc_types' : ['M'],       // 인증 수단 설정 계약 된 상품만 기재 [ M:휴대폰, F:금융인증서, I:아이핀, U:공동인증서 ]
                    'method_type' : 'GET',     // 결과 전달 Method type 설정
                    'exp_mods' : [ 'closeButtonOn' ],  // 창 상단 닫기 버튼 활성화
                    request_no: requestNo                  // 요청 고유 번호  20~50byte 사용 가능하며, 비지니스 로직에 따라 수정 가능한 매서드
                },
                { 
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + accessToken,         
                        'X-Intc-DevLang': 'Window11/Node.js'              
                    }
                }
            );
        console.log('인증URL 요청', urlResponse.data);
        request_no = urlResponse.data.request_no;
        auth_url = urlResponse.data.auth_url;
        transaction_id = urlResponse.data.transaction_id;

        // 예시에서는 세션 저장하여 사용
        req.session.transaction_id = transaction_id;
        req.session.auth_url = auth_url;
        req.session.request_no = request_no;

        res.render('intcMain', {
            accessToken,
            iterators,
            ticket,
            transaction_id,
            auth_url,
            request_no
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('내부 오류 발생');
    }
});

 // 2. 인증 결과 상세 조회 API 호출
app.get('/intcSuccess', async(req, res) => {
    const request_no = req.session.request_no;	
    const transaction_id = req.session.transaction_id;
    const accessToken = req.session.accessToken;
    const ticket = req.session.ticket;
    const iterators = req.session.iterators;
    const web_transaction_id = req.query.web_transaction_id;

    const resultUrl = 'https://auth.niceid.co.kr/ido/intc/v1.0/auth/result'
    const resultResponse = await axios.post( resultUrl,
                { 
                    'web_transaction_id' : web_transaction_id,
                    'request_no' : request_no,
                    'transaction_id' : transaction_id,
                },
                { 
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + accessToken,
                        'X-Intc-DevLang': 'Window/Node.js'
                    }
                }
            );
        console.log('인증 결과 API 요청', resultResponse.data);
        const integrity_value = resultResponse.data.integrity_value; 
        const enc_data = resultResponse.data.enc_data;                    

        const keyString = getKeyValue(ticket, transaction_id, iterators);
        const key = keyString.substring(0,32);
        const hmac_key = keyString.substring(48, 48 + 32);

        const integrity = getSha256MacBase64Value(enc_data, hmac_key);
	
        if (integrity === integrity_value) { console.log('무결성 검증 통과 '); } else { console.error('무결성 검증 오류 ');}

        const plain = aesGcmDec(enc_data, key);
        console.log(plain)
        res.render('intcSuccess', {plain});
});

// PBKDF2를 통한 키 유도 
function getKeyValue(ticket, transaction_id, iterators) {
    try {
        const key = crypto.pbkdf2Sync(ticket, transaction_id, iterators, 64, 'sha256');
        let base64 = key.toString('base64');
        base64 = base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
        return base64;
    } catch (error) {
        console.error("Exception: " + error.message);
        return '';
    }
}

// HMAC-SHA256 무결성 검증 
function getSha256MacBase64Value(value, hmac_key) {
    try {
        const hmac = crypto.createHmac('sha256', hmac_key);
        const hashValue = hmac.update(value).digest();
        let base64Value = hashValue.toString('base64');
        base64Value = base64Value.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); 
        return base64Value;
    } catch (error) {
        console.error("getSha256MacBase64Value Error: " + error.message);
        return null;
    }
}

// AES-256-GCM 복호화 
function aesGcmDec(enc_data, key) {
    try {
        let cipherEnc = Buffer.from(enc_data.replace(/-/g, '+').replace(/_/g, '/'),'base64');
        const iv = cipherEnc.slice(0, 16);
        const cipherAndTag = cipherEnc.slice(16);
        const cipherLen = cipherAndTag.length - 16;
        const cipherText = cipherAndTag.slice(0, cipherLen);
        const tag = cipherAndTag.slice(cipherLen, cipherLen + 16);
        const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
        decipher.setAuthTag(tag);
        const decrypted = Buffer.concat([decipher.update(cipherText), decipher.final()]);
        return decrypted.toString('utf8');
    } catch (error) {
        console.error("AES GCM Decryption Error: " + error.message);
        return null;
    }
}